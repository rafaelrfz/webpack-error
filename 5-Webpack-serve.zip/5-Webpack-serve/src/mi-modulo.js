export function saludar (nombre){
    return `Hola ${nombre}`;
}

export function despedir (nombre){
    return `Hasta ${luego()} ${nombre}`;
}

//var x = 777;

export var x = 777;

function luego(){
    return 'luego';
}